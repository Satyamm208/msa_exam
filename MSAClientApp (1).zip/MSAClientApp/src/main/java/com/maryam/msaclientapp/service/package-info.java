
/**
 * Restful services here
 */
package com.maryam.msaclientapp.service;