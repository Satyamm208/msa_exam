/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package client;

import entity.Garmets;
import entity.Ordert;
import java.util.Collection;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 *
 * @author root
 */

@RegisterRestClient(baseUri = "http://localhost:8080/MSAFirstApp/rest/example")
public interface NewInterface {
 
    @GET
    @Path("/getAllGarment")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Garmets> getAllGarment();
    
    @GET
    @Path("/getAllStock")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Ordert> getAllStock();
    
    @GET
    @Path("/getAllGarmentsDetails/{catName}")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Ordert> getAllGarmentsDetails(@PathParam("catName")String catName);
    
}
