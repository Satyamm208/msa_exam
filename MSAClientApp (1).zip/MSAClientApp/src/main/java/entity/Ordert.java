/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author root
 */
@Entity
@Table(name = "ordert")
@NamedQueries({
    @NamedQuery(name = "Ordert.findAll", query = "SELECT o FROM Ordert o"),
    @NamedQuery(name = "Ordert.fingByStockAndOrder", query = "SELECT o FROM Ordert o WHERE o.garmentId.stock>0"),
    @NamedQuery(name = "Ordert.findByOrderId", query = "SELECT o FROM Ordert o WHERE o.orderId = :orderId")})
public class Ordert implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "orderId")
    private Integer orderId;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Size(min = 1, max = 65535)
    @Column(name = "date")
    private String date;
    @JoinColumn(name = "custId", referencedColumnName = "custId")
    @ManyToOne(optional = false)
    private Customer custId;
    @JoinColumn(name = "garmentId", referencedColumnName = "garmentId")
    @ManyToOne(optional = false)
    private Garmets garmentId;

    public Ordert() {
    }

    public Ordert(Integer orderId) {
        this.orderId = orderId;
    }

    public Ordert(Integer orderId, String date) {
        this.orderId = orderId;
        this.date = date;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Customer getCustId() {
        return custId;
    }

    public void setCustId(Customer custId) {
        this.custId = custId;
    }

    public Garmets getGarmentId() {
        return garmentId;
    }

    public void setGarmentId(Garmets garmentId) {
        this.garmentId = garmentId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (orderId != null ? orderId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ordert)) {
            return false;
        }
        Ordert other = (Ordert) object;
        if ((this.orderId == null && other.orderId != null) || (this.orderId != null && !this.orderId.equals(other.orderId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Ordert[ orderId=" + orderId + " ]";
    }
    
}
