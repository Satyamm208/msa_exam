/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 *
 * @author root
 */
@Entity
@Table(name = "garmets")
@NamedQueries({
    @NamedQuery(name = "Garmets.findAll", query = "SELECT g FROM Garmets g"),
    @NamedQuery(name = "Garmets.findByGarmentId", query = "SELECT g FROM Garmets g WHERE g.garmentId = :garmentId"),
    @NamedQuery(name = "Garmets.findByPrice", query = "SELECT g FROM Garmets g WHERE g.price = :price"),
    @NamedQuery(name = "Garmets.findByStock", query = "SELECT g FROM Garmets g WHERE g.stock = :stock")})
public class Garmets implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "garmentId")
    private Integer garmentId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "price")
    private int price;
    @Basic(optional = false)
    @NotNull
    @Column(name = "stock")
    private int stock;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "garmentId")
    private Collection<Ordert> ordertCollection;
    @JoinColumn(name = "catId", referencedColumnName = "catId")
    @ManyToOne(optional = false)
    private Category catId;

    public Garmets() {
    }

    public Garmets(Integer garmentId) {
        this.garmentId = garmentId;
    }

    public Garmets(Integer garmentId, int price, int stock) {
        this.garmentId = garmentId;
        this.price = price;
        this.stock = stock;
    }

    public Integer getGarmentId() {
        return garmentId;
    }

    public void setGarmentId(Integer garmentId) {
        this.garmentId = garmentId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    @JsonbTransient
    public Collection<Ordert> getOrdertCollection() {
        return ordertCollection;
    }

    public void setOrdertCollection(Collection<Ordert> ordertCollection) {
        this.ordertCollection = ordertCollection;
    }

    public Category getCatId() {
        return catId;
    }

    public void setCatId(Category catId) {
        this.catId = catId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (garmentId != null ? garmentId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Garmets)) {
            return false;
        }
        Garmets other = (Garmets) object;
        if ((this.garmentId == null && other.garmentId != null) || (this.garmentId != null && !this.garmentId.equals(other.garmentId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Garmets[ garmentId=" + garmentId + " ]";
    }
    
}
