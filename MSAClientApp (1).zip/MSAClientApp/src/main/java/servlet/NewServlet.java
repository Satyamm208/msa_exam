/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import client.NewInterface;
import entity.Garmets;
import entity.Ordert;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.eclipse.microprofile.rest.client.inject.RestClient;

/**
 *
 * @author root
 */
@WebServlet(name = "NewServlet", urlPatterns = {"/NewServlet"})
public class NewServlet extends HttpServlet {
    
    @Inject @RestClient NewInterface ni;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet NewServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            
            Collection<Garmets>  garmets = ni.getAllGarment();
            for (Garmets garmet : garmets) {
                out.println("<h1>Servlet NewServlet at " + garmet.getGarmentId() + "</h1>");
            }
            
            Collection<Ordert>  order = ni.getAllStock();
            for (Ordert ordert : order) {
                out.println("<h1>Servlet NewServlet at " + ordert.getCustId().getCustName() + "</h1>");
            }
            
//            Collection<Ordert> garmentDetail = ni.getAllGarmentsDetails(catName);
            out.println("<h1>Servlet NewServlet at " + request.getContextPath() + "</h1>");
            
            
            out.println("<form>");
            out.println("<input type='text' name='txtCatName'>");
            out.println("<input type='submit' value='submit' name='txtCatName'>");
            
            Collection<Ordert> orders = null;
            
            if(request.getParameter("txtCatName")!= null)
            {
            
                String text = request.getParameter("txtCatName");
                orders = ni.getAllGarmentsDetails(text);
                
                for (Ordert order1 : orders) {
                    out.println("<table border=2>");
                    out.println("<tr>");
                    out.println("<td>" + order1.getCustId().getCustName()+ "</td>");
                    out.println("<td>" + order1.getCustId().getPhone()+ "</td>");
                    out.println("<td>" + order1.getCustId().getCity()+ "</td>");
                    out.println("<td>" + order1.getDate() + "</td>");
                    out.println("</tr>");
                }
            }
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
