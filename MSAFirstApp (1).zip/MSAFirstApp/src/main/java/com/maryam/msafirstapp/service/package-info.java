
/**
 * Restful services here
 */
package com.maryam.msafirstapp.service;