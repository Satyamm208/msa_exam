package com.maryam.msafirstapp.service;

import ejb.ExamSessionBean;
import entity.Garmets;
import entity.Ordert;
import java.util.Collection;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/example")
public class ExampleService {
    
    @Inject ExamSessionBean esb;

    @GET
    public Response get() {
        return Response.ok("Hello, world!").build();
    }
    
    @GET
    @Path("/getAllGarment")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Garmets> getAllGarment(){
        return esb.getAllGarment();
    }
    
    @GET
    @Path("/getAllStock")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Ordert> getAllStock(){
        return esb.getAllStock();
    }
    
    @GET
    @Path("/getAllGarmentsDetails/{catName}")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Ordert> getAllGarmentsDetails(@PathParam("catName")String catName){
        return esb.getAllGarmentsDetails(catName);
    }

}
