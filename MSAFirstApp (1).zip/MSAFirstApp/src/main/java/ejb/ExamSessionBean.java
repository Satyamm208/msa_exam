/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package ejb;

import entity.Garmets;
import entity.Ordert;
import java.util.Collection;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author root
 */
@Stateless
public class ExamSessionBean {
    
    @PersistenceContext(unitName = "MSAFirstAppPU")
    EntityManager em;
    
    public Collection<Garmets> getAllGarment(){
        return em.createNamedQuery("Garmets.findAll").getResultList();
    }
    
    public Collection<Ordert> getAllStock(){
        return em.createNamedQuery("Ordert.fingByStockAndOrder").getResultList();
    }
    
    public Collection<Ordert> getAllGarmentsDetails(String catName){
        return em.createNamedQuery("Ordert.findAllGarmentsDetails").setParameter("catName", catName).getResultList();
    }
    
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
